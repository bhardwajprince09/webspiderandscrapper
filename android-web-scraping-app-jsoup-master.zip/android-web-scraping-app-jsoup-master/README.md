# Android Web Scraping App using Jsoup Library

I'll scrap here, the first portion of [this page](https://developer.android.com/training/index.html)

My expected output is like this screenshot.

<img src="https://raw.githubusercontent.com/hasancse91/android-web-scraping-app-jsoup/master/android_web_scraping_app_by_jsoup.png" width="250" height="444" />

These data are not on a webview of predefined in the App. Contents are comming from that web page.
